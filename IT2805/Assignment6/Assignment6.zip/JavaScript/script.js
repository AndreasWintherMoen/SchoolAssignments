function calculateTax(income, wealth)
{
	document.getElementById('taxInput').value = (0.35 * income) + (0.25 * wealth);
}