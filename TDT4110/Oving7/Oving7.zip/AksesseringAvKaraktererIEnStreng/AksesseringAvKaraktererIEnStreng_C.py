text = input("Skriv inn en tekststreng: ")

print(len(text)-1)
