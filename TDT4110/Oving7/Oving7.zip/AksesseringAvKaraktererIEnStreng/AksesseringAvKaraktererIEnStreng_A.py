text = input("Skriv inn en tekststreng: ")

for char in text:
    print(char)
