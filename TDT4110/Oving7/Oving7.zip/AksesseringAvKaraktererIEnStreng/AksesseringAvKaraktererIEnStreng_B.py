text = input("Skriv inn en tekststreng: ")

if (len(text) >= 3):
    print(text[2])
else:
    print("q")
