for i in range(1,8):
    print("Z" * i)
for j in range(8,0,-1):
    print("Z" * j)
